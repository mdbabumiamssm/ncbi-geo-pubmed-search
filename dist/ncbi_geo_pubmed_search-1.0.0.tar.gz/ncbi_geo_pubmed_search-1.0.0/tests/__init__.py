"""Tests for ncbi-geo-pubmed package"""
